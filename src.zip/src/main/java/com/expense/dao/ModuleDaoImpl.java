package com.expense.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.expense.model.Module;
import com.expense.model.RoleModule;
@Component
@PropertySource(value = "classpath:appQuery.properties", ignoreResourceNotFound = true)
public class ModuleDaoImpl implements ModuleDao {

	@Autowired
	Environment env;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Module> getAllActiveModule() {
		String query=env.getProperty("getAllActiveModule");
		return jdbcTemplate.query(query, new Object[] {  }, new BeanPropertyRowMapper(Module.class));
	}

}
