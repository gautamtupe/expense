package com.expense.dao;

public interface UsersDao {

}
