package com.expense.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import com.expense.model.RoleModule;

@Component
@PropertySource(value = "classpath:appQuery.properties", ignoreResourceNotFound = true)
public class RoleModuleDaoImpl implements RoleModuleDao {

	@Autowired
	Environment env;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<RoleModule> getAllRoleModuleByRoleId(long roleId) {
		List<RoleModule> roleModule=null;
		String query = env.getProperty("getAllRoleModuleByRoleId");
		 roleModule=jdbcTemplate.query(query, new Object[] { roleId }, new BeanPropertyRowMapper(RoleModule.class));
		 System.out.println(roleModule);
		 return roleModule;
	}

	

}
