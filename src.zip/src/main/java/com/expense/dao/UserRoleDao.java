package com.expense.dao;

import java.util.List;

import com.expense.model.UserRole;

public interface UserRoleDao {

	List<UserRole> getAllUserRoleByUserId(long userId);

}
