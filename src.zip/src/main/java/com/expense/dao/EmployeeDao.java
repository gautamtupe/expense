package com.expense.dao;

import java.util.List;

import com.expense.model.Employee;

public interface EmployeeDao {

	List<Employee> getAllEmployee();

}
