package com.expense.dao;

import java.util.List;

import com.expense.model.RoleModule;

public interface RoleModuleDao {

	List<RoleModule> getAllRoleModuleByRoleId(long roleId);



}
