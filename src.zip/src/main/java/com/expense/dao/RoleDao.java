package com.expense.dao;

import java.util.List;

import com.expense.config.ServiceException;
import com.expense.model.Role;

public interface RoleDao {

	List<Role> getAllActiveRole() throws ServiceException;

}
