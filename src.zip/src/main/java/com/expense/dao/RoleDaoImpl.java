package com.expense.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.expense.config.ServiceException;
import com.expense.model.Role;

@Component
@PropertySource(value = "classpath:appQuery.properties", ignoreResourceNotFound = true)
public class RoleDaoImpl implements RoleDao {

	@Autowired
	Environment env;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Role> getAllActiveRole() throws ServiceException {
		String query=env.getProperty("getAllActiveRole");
		return jdbcTemplate.query(query, new Object[] { }, new BeanPropertyRowMapper(Role.class));
	}

}
