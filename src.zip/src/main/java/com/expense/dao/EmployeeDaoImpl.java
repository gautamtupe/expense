package com.expense.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.expense.model.Employee;

@Component
@PropertySource(value = "classpath:appQuery.properties", ignoreResourceNotFound = true)
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	Environment env;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Employee> getAllEmployee() {
		String query=env.getProperty("getAllEmployee");
		return jdbcTemplate.query(query, new Object[] {  }, new BeanPropertyRowMapper(Employee.class));
	}

}
