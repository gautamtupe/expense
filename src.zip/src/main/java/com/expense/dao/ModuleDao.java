package com.expense.dao;

import java.util.List;

import com.expense.model.Module;

public interface ModuleDao {

	List<Module> getAllActiveModule();

}
