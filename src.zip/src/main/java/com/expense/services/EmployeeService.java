package com.expense.services;

import java.util.List;

import com.expense.config.ServiceException;
import com.expense.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployee() throws ServiceException;

}
