package com.expense.services;

import java.util.List;

import com.expense.model.RoleModule;
import com.expense.model.Status;

public interface RoleModuleService {

	List<RoleModule> getAllRoleModule();

	RoleModule getRoleModuleById(long roleModuleId);

	Status updateRoleModule(RoleModule roleModule);

	List<RoleModule> getAllRoleModuleByRoleId(long roleId);

}
