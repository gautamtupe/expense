package com.expense.services;

import java.util.List;

import com.expense.config.ServiceException;
import com.expense.model.Role;
import com.expense.model.Status;

public interface RoleService {

	List<Role> getAllRoles();

	Role getRoleById(long roleId);

	Status updateRole(Role role);

	List<Role> getAllActiveRole() throws ServiceException;

}
