package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.config.ServiceException;
import com.expense.dao.RoleDao;
import com.expense.model.Role;
import com.expense.model.Status;
import com.expense.repository.RoleRepository;
@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	RoleDao roleDao;
	
	@Autowired
	RoleRepository roleRepository;
	
	@Override
	public List<Role> getAllRoles() {
		return roleRepository.findAll();
	}

	@Override
	public Role getRoleById(long roleId) {
		return roleRepository.findById(roleId).get();
	}

	@Override
	public Status updateRole(Role role) {
		Status status=new Status();
		if(roleRepository.existsById(role.getRoleId())) {
			role = roleRepository.save(role);
			status.setData(role);
			status.setMessage("Record updated successfully.");
			return status;
		} else {
			roleRepository.saveAndFlush(role);//roleRepository.save(role);
			status.setData(role);
			status.setMessage("Record save successfully.");
			return status;
		}
	}

	@Override
	public List<Role> getAllActiveRole() throws ServiceException {
		return roleDao.getAllActiveRole();
	}

}
