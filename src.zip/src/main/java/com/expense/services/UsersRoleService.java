package com.expense.services;

import java.util.List;

import com.expense.config.ServiceException;
import com.expense.model.Status;
import com.expense.model.UserRole;

public interface UsersRoleService {

	List<UserRole> getAllUsersRole();

	UserRole getUserRoleById(long userRoleId);

	Status updateUserRole(UserRole userRole);

	List<UserRole> getAllUserRoleByUserId(long userId) throws ServiceException;

}
