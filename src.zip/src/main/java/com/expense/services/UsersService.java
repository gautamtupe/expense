package com.expense.services;

import java.util.List;

import com.expense.config.ServiceException;
import com.expense.model.Status;
import com.expense.model.Users;

public interface UsersService {

	List<Users> getAllUsers();

	Users getUsersById(long userId);

	Status updateUsers(Users users) throws ServiceException;

}
