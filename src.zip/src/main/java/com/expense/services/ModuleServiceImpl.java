package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.dao.ModuleDao;
import com.expense.model.Module;
import com.expense.model.Status;
import com.expense.repository.ModuleRepository;
@Service
public class ModuleServiceImpl implements ModuleService {

	@Autowired
	ModuleDao moduleDao;
	
	@Autowired
	ModuleRepository moduleRepository;
	
	@Override
	public List<Module> getAllModule() {
		return moduleRepository.findAll();
	}

	@Override
	public Module getModuleById(long moduleId) {
		return moduleRepository.findById(moduleId).get();
	}

	@Override
	public Status updateModule(Module module) {
		Status status=new Status();
		if(moduleRepository.existsById(module.getModuleId())) {
			module=moduleRepository.save(module);
			status.setData(module);
			status.setMessage("Record updated successfully");
			return status;
		} else {
			module=moduleRepository.save(module);
			status.setData(module);
			status.setMessage("Record save successfully");
			return status;
		}
	}

	@Override
	public List<Module> getAllActiveModule() {
		return moduleDao.getAllActiveModule();
	}

}
