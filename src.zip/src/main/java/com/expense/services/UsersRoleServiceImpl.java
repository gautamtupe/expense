package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.config.ServiceException;
import com.expense.dao.UserRoleDao;
import com.expense.model.Status;
import com.expense.model.UserRole;
import com.expense.repository.UserRoleRepository;
@Service
public class UsersRoleServiceImpl implements UsersRoleService {

	@Autowired
	UserRoleDao userRoleDao;
	
	@Autowired
	UserRoleRepository userRoleRepository;
	
	@Override
	public List<UserRole> getAllUsersRole() {
		return userRoleRepository.findAll();
	}

	@Override
	public UserRole getUserRoleById(long userRoleId) {
		return userRoleRepository.findById(userRoleId).get();
	}

	@Override
	public Status updateUserRole(UserRole userRole) {
		Status status = new Status();
		if(userRoleRepository.existsById(userRole.getUserRoleId())) {
			userRoleRepository.save(userRole);
			status.setMessage("Record updated successfully.");
		} else {
			userRoleRepository.save(userRole);
			status.setMessage("Record save successfully.");
		}
		return status;
	}

	@Override
	public List<UserRole> getAllUserRoleByUserId(long userId) throws ServiceException{
		List<UserRole> list=null;
		try {
			list=userRoleDao.getAllUserRoleByUserId(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
