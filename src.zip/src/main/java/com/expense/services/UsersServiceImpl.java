package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.config.ServiceException;
import com.expense.dao.UsersDao;
import com.expense.model.Employee;
import com.expense.model.Status;
import com.expense.model.Users;
import com.expense.repository.UsersRepository;

@Service
public class UsersServiceImpl implements UsersService {

	@Autowired
	UsersDao usersDao;
	
	@Autowired
	UsersRepository usersRepository;
	
	
	@Override
	public List<Users> getAllUsers() {
		return usersRepository.findAll();
	}

	@Override
	public Users getUsersById(long userId) {
		return usersRepository.findById(userId).get();
	}

	@Override
	public Status updateUsers(Users users) throws ServiceException{
		Status status=new Status();
		try {
			
			if(usersRepository.existsById(users.getUserId())) {
				users = usersRepository.save(users);
				status.setData(users);
				status.setMessage("Data updated successfully.");
			} else {
				users = usersRepository.save(users);
				status.setData(users);
				status.setMessage("Data save successfully.");
			}
		
		} catch (Exception e) {
			status.setMessage("Operation failed.");
			e.printStackTrace();
		}
		
		return status;
	}

}
