package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.dao.RoleModuleDao;
import com.expense.model.RoleModule;
import com.expense.model.Status;
import com.expense.repository.RoleModuleRepository;

@Service
public class RoleModuleServiceImpl implements RoleModuleService {

	@Autowired
	RoleModuleDao roleModuleDao;
	
	@Autowired
	RoleModuleRepository roleModuleRepository;
	
	@Override
	public List<RoleModule> getAllRoleModule() {
		return roleModuleRepository.findAll();
	}

	@Override
	public RoleModule getRoleModuleById(long roleModuleId) {
		return roleModuleRepository.findById(roleModuleId).get();
		//return roleModuleDao.getRoleModuleById(roleModuleId);
	}

	@Override
	public Status updateRoleModule(RoleModule roleModule) {
		Status status=new Status();
		if(roleModuleRepository.existsById(roleModule.getUserRoleModuleId())) {
			roleModule=roleModuleRepository.save(roleModule);
			status.setData(roleModule);
			status.setMessage("Record updated successfully");
			return status;
		} else {
			roleModule=roleModuleRepository.save(roleModule);
			status.setData(roleModule);
			status.setMessage("Record save successfully");
			return status;
		}
	}

	@Override
	public List<RoleModule> getAllRoleModuleByRoleId(long roleId) {
		return roleModuleDao.getAllRoleModuleByRoleId(roleId);
	}

}
