package com.expense.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.expense.config.ServiceException;
import com.expense.dao.EmployeeDao;
import com.expense.model.Employee;
import com.expense.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> getAllEmployee() throws ServiceException{
		List<Employee> employees=null;
		try {
			employees= employeeDao.getAllEmployee();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return employees;
	}

}
