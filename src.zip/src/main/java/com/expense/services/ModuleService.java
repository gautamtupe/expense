package com.expense.services;

import java.util.List;

import com.expense.model.Module;
import com.expense.model.Status;

public interface ModuleService {

	List<Module> getAllModule();

	Module getModuleById(long moduleId);

	Status updateModule(Module module);

	List<Module> getAllActiveModule();

}
