package com.expense.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "M_ROLE_MODULE")
@JsonInclude(Include.NON_NULL)
public class RoleModule {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "M_ROLE_MODULE_S")
	@SequenceGenerator(name = "M_ROLE_MODULE_S", sequenceName = "M_ROLE_MODULE_SEQUENCE", allocationSize = 1)
	@Column(name = "USERROLEMODULEID", updatable = false, nullable = false)
	private long userRoleModuleId;
	
	@Column(name = "ROLEID")
	private long roleId;
	
	@Column(name = "MODULEID")
	private long moduleId;
	
	@Transient
	private String moduleName;
	
	
	@Column(name = "CREATEFLAG")
	private String createFlag;
	
	

	@Column(name = "EDITFLAG")
	private String editFlag;
	
	@Column(name = "READFLAG")
	private String readFlag;
	
	@Column(name = "DELETEFLAG")
	private String deleteFlag;
	
	@Column(name = "STARTDATE")
	private Date startDate;
	
	@Column(name = "ENDDATE")
	private Date endDate;
	
	
	@Column(name = "CREATEDBY")
	private long createdBy;
	
	@Column(name = "CREATIONDATE")
	private Date creationDate;
	
	@Column(name = "LASTUPDATEDBY")
	private long lastUpdatedBy;
	
	@Column(name = "LASTUPDATEDATE")
	private Date lastUpdateDate;
	
	@Column(name = "LASTUPDATELOGIN")
	private long lastUpdateLogin;

	public long getUserRoleModuleId() {
		return userRoleModuleId;
	}

	public void setUserRoleModuleId(long userRoleModuleId) {
		this.userRoleModuleId = userRoleModuleId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public long getModuleId() {
		return moduleId;
	}

	public void setModuleId(long moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getCreateFlag() {
		return createFlag;
	}

	public void setCreateFlag(String createFlag) {
		this.createFlag = createFlag;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getReadFlag() {
		return readFlag;
	}

	public void setReadFlag(String readFlag) {
		this.readFlag = readFlag;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getLastUpdateLogin() {
		return lastUpdateLogin;
	}

	public void setLastUpdateLogin(long lastUpdateLogin) {
		this.lastUpdateLogin = lastUpdateLogin;
	}

	public RoleModule() {
		// TODO Auto-generated constructor stub
	}

	public RoleModule(long userRoleModuleId, long roleId, long moduleId, String moduleName, String createFlag,
			String editFlag, String readFlag, String deleteFlag, Date startDate, Date endDate, long createdBy,
			Date creationDate, long lastUpdatedBy, Date lastUpdateDate, long lastUpdateLogin) {
		this.userRoleModuleId = userRoleModuleId;
		this.roleId = roleId;
		this.moduleId = moduleId;
		this.moduleName = moduleName;
		this.createFlag = createFlag;
		this.editFlag = editFlag;
		this.readFlag = readFlag;
		this.deleteFlag = deleteFlag;
		this.startDate = startDate;
		this.endDate = endDate;
		this.createdBy = createdBy;
		this.creationDate = creationDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdateLogin = lastUpdateLogin;
	}

	
	
}
