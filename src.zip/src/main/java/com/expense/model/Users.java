package com.expense.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "M_USERS")
@JsonInclude(Include.NON_NULL)
public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "M_USERS_S")
	@SequenceGenerator(name = "M_USERS_S", sequenceName = "M_USERS_SEQUENCE", allocationSize = 1)
	@Column(name = "USERID", updatable = false, nullable = false)
	private long userId;
	
	@Column(name = "USERNAME")
	private String userName;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "EMPLOYEEID")
	private long employeeId;
	
	@Column(name = "STARTDATE")
	private Date startDate;
	
	@Column(name = "ENDDATE")
	private Date endDate;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "PASSWORD")
	private String password;
	
	@Column(name = "PASSWORDDATE")
	private Date passwordDate;
	
	@Column(name = "CHANGEPWD")
	private String changePwd;
	
	@Column(name = "CREATEDBY")
	private long createdBy;
	
	@Column(name = "CREATIONDATE")
	private Date creationDate;
	
	@Column(name = "LASTUPDATEDBY")
	private long lastUpdatedBy;
	
	@Column(name = "LASTUPDATEDATE")
	private Date lastUpdateDate;
	
	@Column(name = "LASTUPDATELOGIN")
	private long lastUpdateLogin;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getPasswordDate() {
		return passwordDate;
	}

	public void setPasswordDate(Date passwordDate) {
		this.passwordDate = passwordDate;
	}

	public String getChangePwd() {
		return changePwd;
	}

	public void setChangePwd(String changePwd) {
		this.changePwd = changePwd;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getLastUpdateLogin() {
		return lastUpdateLogin;
	}

	public void setLastUpdateLogin(long lastUpdateLogin) {
		this.lastUpdateLogin = lastUpdateLogin;
	}

	public Users() {
		// TODO Auto-generated constructor stub
	}

	public Users(long userId, String userName, String email, long employeeId, Date startDate, Date endDate,
			String status, String description, String password, Date passwordDate, String changePwd, long createdBy,
			Date creationDate, long lastUpdatedBy, Date lastUpdateDate, long lastUpdateLogin) {
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.employeeId = employeeId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.description = description;
		this.password = password;
		this.passwordDate = passwordDate;
		this.changePwd = changePwd;
		this.createdBy = createdBy;
		this.creationDate = creationDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdateLogin = lastUpdateLogin;
	}

	@Override
	public String toString() {
		return "Users [userId=" + userId + ", userName=" + userName + ", email=" + email + ", employeeId=" + employeeId
				+ ", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status + ", description="
				+ description + ", password=" + password + ", passwordDate=" + passwordDate + ", changePwd=" + changePwd
				+ ", createdBy=" + createdBy + ", creationDate=" + creationDate + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdateDate=" + lastUpdateDate + ", lastUpdateLogin=" + lastUpdateLogin + "]";
	}

		

}
