package com.expense.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Entity
@Table(name = "M_MODULE")
@JsonInclude(Include.NON_NULL)
public class Module {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "M_ROLE_S")
	@SequenceGenerator(name = "M_ROLE_S", sequenceName = "M_ROLE_SEQUENCE", allocationSize = 1)
	@Column(name = "MODULEID", updatable = false, nullable = false)
	private long moduleId;
	
	@Column(name = "MODULECODE")
	private String moduleCode;
	
	@Column(name = "MODULENAME")
	private String moduleName;
	
	@Column(name = "MODULEDESC")
	private String moduleDesc;
	
	@Column(name = "MODULEURL")
	private String moduleUrl;
	
	@Column(name = "MODULEGROUP")
	private String moduleGroup;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "STARTDATE")
	private Date startDate;
	
	@Column(name = "ENDDATE")
	private Date endDate;
	
	@Column(name = "CREATEDBY")
	private long createdBy;
	
	@Column(name = "CREATIONDATE")
	private Date creationDate;
	
	@Column(name = "LASTUPDATEDBY")
	private long lastUpdatedBy;
	
	@Column(name = "LASTUPDATEDATE")
	private Date lastUpdateDate;
	
	@Column(name = "LASTUPDATELOGIN")
	private long lastUpdateLogin;

	public long getModuleId() {
		return moduleId;
	}

	public void setModuleId(long moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleDesc() {
		return moduleDesc;
	}

	public void setModuleDesc(String moduleDesc) {
		this.moduleDesc = moduleDesc;
	}

	public String getModuleUrl() {
		return moduleUrl;
	}

	public void setModuleUrl(String moduleUrl) {
		this.moduleUrl = moduleUrl;
	}

	public String getModuleGroup() {
		return moduleGroup;
	}

	public void setModuleGroup(String moduleGroup) {
		this.moduleGroup = moduleGroup;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getLastUpdateLogin() {
		return lastUpdateLogin;
	}

	public void setLastUpdateLogin(long lastUpdateLogin) {
		this.lastUpdateLogin = lastUpdateLogin;
	}

	public Module() {
		// TODO Auto-generated constructor stub
	}

	public Module(long moduleId, String moduleCode, String moduleName, String moduleDesc, String moduleUrl,
			String moduleGroup, String status, Date startDate, Date endDate, long createdBy, Date creationDate,
			long lastUpdatedBy, Date lastUpdateDate, long lastUpdateLogin) {
		this.moduleId = moduleId;
		this.moduleCode = moduleCode;
		this.moduleName = moduleName;
		this.moduleDesc = moduleDesc;
		this.moduleUrl = moduleUrl;
		this.moduleGroup = moduleGroup;
		this.status = status;
		this.startDate = startDate;
		this.endDate = endDate;
		this.createdBy = createdBy;
		this.creationDate = creationDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdateLogin = lastUpdateLogin;
	}

	
	

}
