package com.expense.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.expense.model.RoleModule;
import com.expense.model.Status;
import com.expense.services.RoleModuleService;

@RestController
@RequestMapping("/api/rolemodule")
public class RoleModuleController {

	@Autowired
	RoleModuleService roleModuleService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<RoleModule>> getAllRoleModule(){
		List<RoleModule> roleModule=null;
		try {
			roleModule=roleModuleService.getAllRoleModule();
			return new ResponseEntity<List<RoleModule>>(roleModule,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<RoleModule>>(roleModule,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getallrolemodulebyroleid/{roleId}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<RoleModule>> getAllRoleModuleByRoleId(@PathVariable(value="roleId") long roleId){
		List<RoleModule> roleModules=null;
		try {
			roleModules = roleModuleService.getAllRoleModuleByRoleId(roleId);
			return new ResponseEntity<List<RoleModule>>(roleModules,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<RoleModule>>(roleModules,HttpStatus.EXPECTATION_FAILED);
		
	}
	
	@RequestMapping(value = "/getbyid/{roleModuleId}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> getRoleModuleById(@PathVariable(value = "roleModuleId") long roleModuleId){
		Status status=new Status();
		try {
			RoleModule roleModule=new RoleModule();
			roleModule = roleModuleService.getRoleModuleById(roleModuleId);
			status.setData(roleModule);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/saverolemodule", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> updateRoleModule(@RequestBody RoleModule roleModule){
		Status status=new Status();
		try {
			status = roleModuleService.updateRoleModule(roleModule);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
	
	
	
}
