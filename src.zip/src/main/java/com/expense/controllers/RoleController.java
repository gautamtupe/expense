package com.expense.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.expense.config.ServiceException;
import com.expense.model.Role;
import com.expense.model.Status;
import com.expense.services.RoleService;

@RestController
@RequestMapping("/api/role")
public class RoleController {

	@Autowired
	RoleService roleService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Role>> getAllRoles(){
		List<Role> role=null;
		try {
			role=roleService.getAllRoles();
			return new ResponseEntity<List<Role>>(role,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<Role>>(role,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getallactiverole", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Role>> getAllActiveRole() throws ServiceException{
		return new ResponseEntity<List<Role>>(roleService.getAllActiveRole(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getbyid/{roleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> getRoleById(@PathVariable(value="roleId") long roleId){
		Status status=new Status();
		try {
			Role role=new Role();
			role = roleService.getRoleById(roleId);
			status.setData(role);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/saverole", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> updateRole(@RequestBody Role role){
		Status status=new Status();
		try {
			status = roleService.updateRole(role);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
}
