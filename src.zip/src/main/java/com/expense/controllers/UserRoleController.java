package com.expense.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.expense.config.ServiceException;
import com.expense.model.Status;
import com.expense.model.UserRole;
import com.expense.services.UsersRoleService;

@RestController
@RequestMapping("/api/userrole")
public class UserRoleController {

	@Autowired
	UsersRoleService userRoleService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserRole>> getAllUsersRole(){
		List<UserRole> userRole=null;
		try {
			userRole = userRoleService.getAllUsersRole();
			return new ResponseEntity<List<UserRole>>(userRole,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<UserRole>>(userRole,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getbyid/{userRoleId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> getUserRoleById(@PathVariable(name = "userRoleId") long userRoleId){
		Status status=new Status();
		try {
			UserRole userRole=new UserRole();
			userRole = userRoleService.getUserRoleById(userRoleId);
			status.setData(userRole);
			return new ResponseEntity<Status>(status, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status, HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/saveuserrole", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> updateUserRole(@RequestBody UserRole userRole){
		Status status=new Status();
		try {
			status = userRoleService.updateUserRole(userRole);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getalluserrolebyuserid/{userId}",method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UserRole>> getAllUserRoleByUserId(@PathVariable(value = "userId") long userId) throws ServiceException{
		return new ResponseEntity<List<UserRole>>(userRoleService.getAllUserRoleByUserId(userId),HttpStatus.OK);
		
	}
}
