package com.expense.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.expense.config.ServiceException;
import com.expense.model.Status;
import com.expense.model.Users;
import com.expense.services.UsersService;

@RestController
@RequestMapping("/api/users")
public class UsersController {

	@Autowired
	UsersService usersService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Users>> getAllUsers() {
		List<Users> users=null;
		try {
			users= usersService.getAllUsers(); 
			return new ResponseEntity<List<Users>>(users, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<Users>>(users,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getbyid/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> getUsersById(@PathVariable(value = "id") long userId){
		Status status=new Status();
		try {
			Users users=new Users();
			users= this.usersService.getUsersById(userId);
			status.setData(users);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status, HttpStatus.EXPECTATION_FAILED);
	}
	
	
	@RequestMapping(value = "/saveusers", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> updateUsers(@RequestBody Users users) throws ServiceException{
		return new ResponseEntity<Status>(usersService.updateUsers(users),HttpStatus.OK);
	}
	
	
	
}
