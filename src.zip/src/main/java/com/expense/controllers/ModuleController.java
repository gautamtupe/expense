package com.expense.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.expense.model.Module;
import com.expense.model.Status;
import com.expense.services.ModuleService;

@RestController
@RequestMapping("/api/module")
public class ModuleController {

	@Autowired
	ModuleService moduleService;
	
	@RequestMapping(value = "/getall", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Module>> getAllModule(){
		List<Module> module=null;
		try {
			module=moduleService.getAllModule();
			return new ResponseEntity<List<Module>>(module,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<Module>>(module,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getallactivemodule", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Module>> getAllActiveModule(){
		List<Module> module=null;
		try {
			module=moduleService.getAllActiveModule();
			return new ResponseEntity<List<Module>>(module,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<List<Module>>(module,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/getbyid/{moduleId}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> getModuleById(@PathVariable(value = "moduleId") long moduleId){
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+moduleId);
		Status status=new Status();
		try {
			Module module=new Module();
			module = moduleService.getModuleById(moduleId);
			status.setData(module);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
	@RequestMapping(value = "/savemodule", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> updateModule(@RequestBody Module module){
		Status status=new Status();
		try {
			status = moduleService.updateModule(module);
			return new ResponseEntity<Status>(status,HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Status>(status,HttpStatus.EXPECTATION_FAILED);
	}
	
}
